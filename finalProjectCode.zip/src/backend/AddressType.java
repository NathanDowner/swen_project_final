package backend;

import java.io.Serializable;

/**
 * 
 */
public enum AddressType implements Serializable{
    Home,
    Work
}