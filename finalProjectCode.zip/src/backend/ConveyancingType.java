package backend;

public enum ConveyancingType {
    Sale,
    Purchase,
    LandTitleRegistration,
    LostTitleApplication,
    ApplicationToNoteDeath,
    ApplicationToNoteMarriage
}